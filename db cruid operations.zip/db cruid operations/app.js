 require("./db/mongoose")
 const validator =require("validator")

 const express=require("express")
 const app= express()

app.use(express.json())    //parsing automatically data you enter in req.body to object

 const userRouter=require("./routers/user")
 const taskRouter=require("./routers/task")
 const articleRouter=require("./routers/article")

 app.use(userRouter)
 app.use( taskRouter)
 app.use(articleRouter)



 const port = process.env.PORT || 3000;



 

app.listen(port,()=>{   
    console.log("all done successfully")
})