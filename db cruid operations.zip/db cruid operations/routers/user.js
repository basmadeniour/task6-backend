const express=require("express")
const User = require("../models/users")
const jwt =require("jsonwebtoken")
const auth = require("../middleware/auth");

const router=express.Router()
///////post
router.post("/users",(req,res)=>{      //the first parameter is the page which contain the conditions that will be chicked
    // console.log(req.body)              //req.body is the data you add

    const user =new User(req.body)

    user.save()
    .then((user)=>{res.status(200).send(user)})
    .catch((e)=>{res.status(400).send(e)})
})

//Get
router.get("/users",(req,res)=>{
    User.find({})
    .then((user)=>res.status(200).send(user))
    .catch((e)=>{res.status(400).send(e)})
})
//specific user
router.get("/users/:id",(req,res)=>{
    // console.log(req.params)
    const _id =req.params
    User.findById(_id)
    .then((user)=>{
    if(!user)
        {
       return res.status(404).send("un able to find this user")
        }
        res.status(200).send({user})
    .catch((e)=>{res.status(500).send(e)})
})
})

//patch
router.patch("/users/:id",async(req,res)=>{
    try{
        //to hold updated data we use object.keys
        const updates =Object.keys(req.body)
        const _id =req.params.id

//   findByIdAndUpdate method saves automatically after updata the data without hasing the pasword ,to solve

       const user =await User.findById(_id )
   
   if (!user){
    return res.status(404).send("no user found")
   }
   updates.forEach((ele)=>(user[ele]=req.body[ele]))   
   //here we cannot use . notation without assign every array of element separately
   
   await user.save()
   res.status(200).send(user)
    }

    catch(e){res.status(400).send(e)}
})



// const user = await User.findByIdAndUpdate(_id,req.body,{
//    new:true,            
//    runValidators:true
//    //witout new:true it will update data in database ,and still send the old data to the res.body of postman
//   // runValidators keeps the validate conditions on your model
// })

  

//Delete
router.delete("/users/:id",async (req,res)=>{
    try{
        const _id= req.params.id
        const user=await User.findByIdAndDelete(_id)
        if (!user){
            res.status(404).send("faild to delete this user")
        }
        res.status(200).send(user)
    }
    catch(e){res.status(400).send(e)}
})



//////login
//the idea of login is that when user enter ,check if password and email issigned up before to login or not
// so the opreation will be excuted when post  (enter data that will be checked)

    router.post("/login", async (req, res) => {
        try {
            const user = await User.findByCredentials(req.body.email, req.body.password);
            const token =await user.generateToken()
            res.status(200).send({user,token}
            );
        }
        catch(e){
            res.status(400).send({ error: e.message });
        }
    });
    

///////////////////////////////

 //user authorizations
router.post("/users",async(req,res)=>{
    try{
    const user =new User(req.body)
    const token =await user.generateToken()
    user.save()
    res.status(200).send({user,token})
    }
    catch(e){
        res.status(400).send(e)
    }
}) 

/////////////////////////////////////
//user profile
router.get("/profile",auth,(req,res)=>{
    res.status(200).send(req.user)    //req.user = user
})

/////////////////////////////////////
//logout
router.delete("logout",auth,async(req,res)=>{
    try{
        console.log(req.user)
        req.user.tokens = req.user.tokens.filter((el)=>{
            return el!== req.token
        })
        await req.user.save()
        res.send()
    }
    catch(e){
        res.status(500).send(e)
    }
})

module.exports=router 
