const express=require("express")
const Article =require("../models/articles")
// const {findByIdAndDelete}=require("../models/users")
const auth =require("../middleware/auth")

const router=express.Router()

router.post("/articles",auth,async(req,res)=>{
    try{
        const article =new Task({...req.body,owner:req.user._id})
        await article.save()
        res.status(200).send(article)
    }
    catch(e){
        res.status(400).send(e.message)
    }
})

router.get("/articles",auth,async(req,res)=>{
    try{
        const article= await Article.find({})
        res.status(200).send(article)
    }
    catch(e){
        res.status(500).send(e.message)
    }
})

router.get("/articles/:id",auth,async(req,res)=>{
    try{
        // const tasks = await Task.findById(req.params.id)
        const article=await Article.findOne({_id , owner : req.user._id})
        const _id =req.params.id
        if (!article){
            return res.status(404).send("un able to find task")
        }
        res.status(200).send(article)
    }
    catch(e){
        res.status(500).send(e.message)
    }
})

router.patch("/articles/:id",auth,async(req,res)=>{
    try{
        const _id=req.params.id
        const article =await Article.findByIdAndUpdate({_id},req.body,{
            new:true,
            runvalidators:true
        })
        if (!article){
            return res.status(404).send("un able to find task")
        }
    }
    catch(e){
        res.status(500).send(e.message)
    }
})


router.delete("/articles/:id",auth,async(req,res)=>{
    try{
        const _id=req.params.id
        const article =await Article.findByIdAndDelete({_id})
        if (!article){
            return res.status(404).send("un able to find task")
        }
        res.status(200).send(article)
    }
    catch(e){
        res.status(500).send(e.message)
    }
})

module.exports=router 