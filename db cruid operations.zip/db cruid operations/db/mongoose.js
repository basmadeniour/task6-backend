const mongoose=require("mongoose")
 mongoose.connect("mongodb://127.0.0.1:27017/db-cruidOperations")
 //mongoose.connect('mongodb://127.0.0.1:27017/db-crudOperations'); // Default MongoDB port is 27017

 