const mongoose=require("mongoose")
const { type } = require("os")

const bcryptjs=require("bcryptjs")
const userschema = new mongoose.Schema(
    {
        username:{
            type:String,
            required:true,
            trim:true
        },
        password:{
            type:String,
            required:true,
            trim:true,
            minlength:8,
            validate(value){
                let password=new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])");
                if (!password.test(value)){
                    throw new Error("password must include uppercase , lower case , numbers , special charaters")
                }
            }
        },
        email:{
            type:String,
            required:true,
            trim:true,
            lowercase:true,
            unique:true,
            valdiate(val){
                if(!validator.isEmail(val)){
                    throw new Error("Email is INVALID")
                }
            }
        },
        age:{
            type:Number,
            default:18,
            validate (val){
                if (val <= 0)
                {
                    throw new Error("Age must be postive Number")
                }
            }
        },
        city:{
            type:String  
        },
        tokens:[
            {
                type:String,
                required:true,
            }
        ]
    }
)
//////password hasing
userschema.pre("save", async function ()
{
    const user = this   ///this here refere to the docs that entered by user   ("postman")
   //to make the password be hased only after update it ,in case of patch
   if (user.isModified("password"))
   {
    user.password =await bcryptjs.hash(user.password, 8)
   }
    
})

////login
//using findByCredentials function we compare the data user login with ,with the data stored before
//statics here allow you to use function in the model 
userschema.statics.findByCredentials=async(mail,passssword)=>{
    //email==>which stored in db before       mail==>user enter when login in req.body
    const user =await User.findOne({email:mail})
    if (!user){
        throw new Error("this user didnot register before , please sign up now")
    }
    //after check the email,we must compare  
    const ismatch=await bcryptjs.compare(passssword,user.password)
    if (!ismatch){
        throw new Error("this user didnot register before , please sign up now")
    }

    //when the email , password is true
    return user
}


 //////Token
    const jwt =require("jsonwebtoken")
    userschema.methods.generateToken= async function () {
    const user=this
    const token =jwt.sign({_id:user._id.toString()},"Basma#05")    //id must be string   , the 2end parameter is secuir key
    user.tokens=user.tokens.concat(token)
    await user.save()
    return token;

} 

//////hide private data 

userschema.methods.toJSON=function(){
    const user=this
    const userObject=user.toObject()      //convert doc to obtect to be able to deal with it
    delete userObject.password
    delete userObject.tokens
    return userObject

}





const User=mongoose.model("User",userschema)
module.exports=User